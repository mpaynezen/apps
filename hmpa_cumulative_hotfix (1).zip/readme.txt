Sophos HitmanPro.Alert 3.8.3.107 Hotfix
=======================================

Hotfix
------
For further information in regards to the Cumulative Hotfix, please follow this
link: https://www.sophos.com/kb/133140

About
-----
Sophos HitmanPro.Alert provides state-of-the-art signature-less protection from
zero-day threats. On Windows Servers, Sophos CryptoGuard protects document files
from locally and remotely running ransomware.


Documentation
-------------
For general information about Sophos HitmanPro.Alert and Sophos CryptoGuard,
please follow this link: http://www.surfright.com/en/alert.


Legal notices
-------------
Copyright 1989-2021 Sophos Limited. All rights reserved. All rights reserved.

Sophos is a trademark of Sophos Limited. HitmanPro.Alert and CryptoGuard are
trademarks of SurfRight B.V. All other product and company names mentioned are
trademarks or registered trademarks of their respective owners.

This Sophos product may include certain Microsoft software, licensed to Sophos
for inclusion and use herein.
